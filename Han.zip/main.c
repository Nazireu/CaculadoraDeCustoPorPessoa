#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
	setlocale(LC_ALL,"Portuguese");

	int qtdepessoa,temmulta;
	float conta;
	float rateio, multa;
  
	multa=0;
	printf("Digite quantidade de pessoas: ");
	scanf("%d",&qtdepessoa);
	
	printf("Digite valor da conta R$ ");
	scanf("%f",&conta);	

  printf ("Tem multa? Digite 1 se tiver multa:");
  scanf("%d",&temmulta);

  if (temmulta == 1)
  {
    printf("Qual valor da multa?");
    scanf("%f",&multa);
  
  }


	rateio = (conta+multa) / qtdepessoa;	
	printf("Cada um terá que pagar R$ %.2f.\n\n",rateio);	
	return 0;
}